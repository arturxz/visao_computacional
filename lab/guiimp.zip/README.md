
GUIIMP

GUIIMP stands for Graphical User Interface for Image Processing. Is a simple GUI for testing image processing functions.

Requires Python 3 and Tk5.

